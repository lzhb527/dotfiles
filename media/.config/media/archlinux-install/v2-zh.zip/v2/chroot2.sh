#!/usr/bin/env bash
# 第二阶段：在 chroot 内运行
set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

msg()  { printf "${GREEN}[==>]${NC} %s\n" "$*"; }
warn() { printf "${YELLOW}[!]${NC} %s\n" "$*"; }
err()  { printf "${RED}[x]${NC} %s\n" "$*" >&2; }

read -rp "请输入主机名: " HOSTNAME
[[ -n "$HOSTNAME" ]] || { err "主机名不能为空"; exit 1; }

read -rp "请输入普通用户名: " USERNAME
[[ -n "$USERNAME" ]] || { err "用户名不能为空"; exit 1; }

disable_sig_check() {
    sed -i 's/^SigLevel.*Required.*DatabaseOptional/SigLevel = Never/' /etc/pacman.conf
    grep -q '^SigLevel = Never' /etc/pacman.conf || \
        sed -i '/^#SigLevel.*/a SigLevel = Never' /etc/pacman.conf
}

set_timezone() {
    msg "时区 -> America/Detroit"
    ln -sf /usr/share/zoneinfo/America/Detroit /etc/localtime
    hwclock --systohc
}

set_locale() {
    msg "生成 locale 并写入 /etc/locale.conf"
    sed -i 's/^#\(en_US.UTF-8 UTF-8\)/\1/' /etc/locale.gen
    locale-gen
    echo "LANG=en_US.UTF-8" > /etc/locale.conf
}

set_hostname() {
    msg "主机名 -> $HOSTNAME"
    echo "$HOSTNAME" > /etc/hostname
    cat > /etc/hosts <<EOF
127.0.0.1   localhost
::1         localhost
127.0.1.1   $HOSTNAME.localdomain $HOSTNAME
EOF
}

setup_zram() {
    msg "安装并配置 zram"
    pacman -S --noconfirm zram-generator

    cat > /etc/systemd/zram-generator.conf <<EOF
[zram0]
zram-size = min(ram / 2, 4096)
compression-algorithm = zstd
swap-priority = 100
EOF

    echo "vm.swappiness = 100" > /etc/sysctl.d/99-zram.conf
}

mkinitcpio_build() {
    msg "重建 initramfs"
    mkinitcpio -P
}

setup_bootloader() {
    msg "安装 systemd-boot"
    bootctl install

    tee /boot/loader/loader.conf >/dev/null <<EOF
default   arch.conf
timeout   15
console-mode max
EOF

    local partuuid
    partuuid=$(blkid -s PARTUUID -o value /dev/sda3)

    tee /boot/loader/entries/arch.conf >/dev/null <<EOF
title   Arch Linux
linux   /Image
initrd  /initramfs-linux.img
options root=PARTUUID=$partuuid rootflags=subvol=@,rw,noatime,compress=zstd:3,ssd,discard=async,space_cache=v2 video=1440x900@60
EOF
}

set_root_pass() {
    msg "设置 root 密码"
    while true; do
        read -rsp "root 密码: " p1; echo
        read -rsp "再次输入: "   p2; echo
        [[ "$p1" == "$p2" && -n "$p1" ]] || { err "不一致或为空"; continue; }
        echo "root:$p1" | chpasswd
        break
    done
}

create_user() {
    msg "创建用户 $USERNAME"
    useradd -m -G wheel "$USERNAME"
    while true; do
        read -rsp "$USERNAME 密码: " p1; echo
        read -rsp "再次输入: "      p2; echo
        [[ "$p1" == "$p2" && -n "$p1" ]] || { err "不一致或为空"; continue; }
        echo "$USERNAME:$p1" | chpasswd
        break
    done

    msg "启用 wheel 组 sudo（取消注释 %wheel 行）"
    sed -i 's/^# %wheel ALL=(ALL:ALL) ALL/%wheel ALL=(ALL:ALL) ALL/' /etc/sudoers
}

enable_services() {
    msg "启用 NetworkManager"
    systemctl enable NetworkManager
}

main() {
    disable_sig_check
    set_timezone
    set_locale
    set_hostname
    setup_zram
    mkinitcpio_build
    setup_bootloader
    set_root_pass
    create_user
    enable_services

    msg "=== chroot 配置完成 ==="
    warn "请回到外层脚本：exit && umount -R /mnt && reboot"
}

main "$@"
