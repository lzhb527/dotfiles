#!/usr/bin/env bash
# Arch Linux 安装脚本 — Btrfs + systemd-boot + zram
# 假设: /dev/sda1 = EFI, /dev/sda2 = SWAP, /dev/sda3 = Btrfs root
set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

msg()  { printf "${GREEN}[==>]${NC} %s\n" "$*"; }
warn() { printf "${YELLOW}[!]${NC} %s\n" "$*"; }
err()  { printf "${RED}[x]${NC} %s\n" "$*" >&2; }

require_root() { [[ $EUID -eq 0 ]] || { err "请以 root 运行"; exit 1; }; }

confirm() {
    local p="${1:-确认继续？}"
    read -rp "$p [y/N]: " a
    [[ "$a" =~ ^[Yy]$ ]]
}

disk_check() {
    for d in /dev/sda1 /dev/sda2 /dev/sda3; do
        [[ -b "$d" ]] || { err "缺少块设备 $d"; exit 1; }
    done
}

disable_sig_check() {
    msg "关闭 pacman 签名校验（Parallels AArch64 兼容）"
    sed -i 's/^SigLevel.*Required.*DatabaseOptional/SigLevel = Never/' /etc/pacman.conf
    sed -i '/^SigLevel = Never/d' /etc/pacman.conf
    sed -i '/^#SigLevel/a SigLevel = Never' /etc/pacman.conf
    grep -q '^SigLevel = Never' /etc/pacman.conf || \
        sed -i 's/^#SigLevel.*/&\nSigLevel = Never/' /etc/pacman.conf
}

disable_sig_check_new() {
    msg "新系统内再次关闭签名校验"
    sed -i 's/^SigLevel.*Required.*DatabaseOptional/SigLevel = Never/' /etc/pacman.conf
    grep -q '^SigLevel = Never' /etc/pacman.conf || \
        sed -i '/^#SigLevel.*/a SigLevel = Never' /etc/pacman.conf
}

phase1_prepare_disk() {
    msg "查看磁盘分区"
    fdisk -l

    confirm "将格式化 /dev/sda1,2,3，是否继续？" || { err "已取消"; exit 1; }

    msg "格式化分区"
    mkfs.fat -F 32 /dev/sda1
    mkswap /dev/sda2
    swapon /dev/sda2
    mkfs.btrfs -f /dev/sda3
}

phase2_create_subvol() {
    msg "创建 Btrfs 子卷"
    mount /dev/sda3 /mnt
    for s in @ @home @log @cache; do
        btrfs subvolume create "/mnt/$s"
    done
    umount /mnt
}

phase3_mount() {
    msg "挂载子卷与 EFI"
    local BTRFS_OPTS="rw,noatime,compress=zstd,ssd,space_cache=v2"
    mount -o "${BTRFS_OPTS},subvol=@"      /dev/sda3 /mnt
    mkdir -p /mnt/{home,var/log,var/cache,boot}
    mount -o "${BTRFS_OPTS},subvol=@home"  /dev/sda3 /mnt/home
    mount -o "${BTRFS_OPTS},subvol=@log"    /dev/sda3 /mnt/var/log
    mount -o "${BTRFS_OPTS},subvol=@cache"  /dev/sda3 /mnt/var/cache
    mount /dev/sda1 /mnt/boot

    lsblk
}

phase4_pacstrap() {
    msg "pacstrap 安装基础包"
    pacstrap /mnt \
        base base-devel linux btrfs-progs \
        grub efibootmgr bash-completion \
        neovim terminus-font git networkmanager

    msg "生成 fstab"
    genfstab -U /mnt >> /mnt/etc/fstab
}

phase5_copy_scripts() {
    local dir; dir="$(dirname "$0")"
    cp "$dir/chroot2.sh" /mnt/chroot2.sh
    chmod +x /mnt/chroot2.sh
}

phase6_chroot() {
    msg "进入 chroot 执行第二阶段"
    arch-chroot /mnt /bin/bash /chroot2.sh
    rm -f /mnt/chroot2.sh
}

main() {
    require_root
    disk_check

    warn "本脚本将抹除 /dev/sda1,2,3 上的数据"
    confirm "是否开始安装？" || exit 1

    disable_sig_check
    phase1_prepare_disk
    phase2_create_subvol
    phase3_mount
    phase4_pacstrap
    phase5_copy_scripts
    phase6_chroot

    msg "=== 安装完成 ==="
    warn "请执行：umount -R /mnt && reboot（重启前弹出安装 ISO）"
}

main "$@"
