-- =====================================================================
-- Neovim 0.10+ Ansible & Python 完美联动开发环境完整配置
-- =====================================================================

-- ====================== 0. 基础环境桥梁与自动安装 ======================

-- 1) 确保 mason-lspconfig 加载并自动下载指定的语言服务器
require("mason-lspconfig").setup({
  ensure_installed = { "pyright", "ansiblels" }, 
})

-- 2) 将 Mason 的二进制下载目录追加到 Neovim 内部的 PATH 中，防止找不到工具崩溃
local mason_bin = vim.fn.stdpath("data") .. "/mason/bin"
if not string.find(vim.env.PATH, mason_bin, 1, true) then
  vim.env.PATH = mason_bin .. vim.path_sep .. vim.env.PATH
end

-- ====================== 1. 文件类型精确映射与全局注册 ======================

-- 1) 强行让 Neovim 核心承认并注册 yaml.ansible 文件类型
vim.filetype.add({
  extension = {
    yml = "yaml.ansible",
    yaml = "yaml.ansible",
  },
  pattern = {
    [".*/ansible-deploy/.*%.ya?ml"] = "yaml.ansible",
    [".*/roles/.*/tasks/.*%.ya?ml"] = "yaml.ansible",
    [".*/playbooks/.*%.ya?ml"] = "yaml.ansible",
    ["site%.ya?ml"] = "yaml.ansible",
    ["deploy%.ya?ml"] = "yaml.ansible",
    ["local%.ya?ml"] = "yaml.ansible",
  },
})

-- ====================== 2. 核心补全能力注入 ======================

local capabilities = vim.lsp.protocol.make_client_capabilities()
if vim.lsp.default_capabilities then
  capabilities = vim.lsp.default_capabilities()
end
local has_cmp, cmp_lsp = pcall(require, "cmp_nvim_lsp")
if has_cmp then
  -- 为传统的 nvim-cmp 注入增强补全支持
  capabilities = vim.tbl_deep_extend("force", capabilities, cmp_lsp.default_capabilities())
end

-- Neovim 0.10+ 全局原生补全能力激活
if vim.lsp.completion and vim.lsp.completion.enable then
  capabilities.textDocument.completion.completionItem.snippetSupport = true
end

-- 通用 LSP 连接（on_attach）快捷键绑定
local on_attach = function(client, bufnr)
  -- 禁用 LSP 默认格式化，交给专用的外部格式化工具
  if client.server_capabilities.documentFormattingProvider then
    client.server_capabilities.documentFormattingProvider = false
  end

  local opts = { buffer = bufnr, silent = true, noremap = true }
  vim.keymap.set("n", "K", vim.lsp.buf.hover, opts)
  vim.keymap.set("n", "gd", vim.lsp.buf.definition, opts)
  vim.keymap.set("n", "gi", vim.lsp.buf.implementation, opts)
  vim.keymap.set("n", "gr", vim.lsp.buf.references, opts)
  vim.keymap.set("n", "<leader>r", vim.lsp.buf.rename, opts)
  vim.keymap.set("n", "<leader>e", vim.diagnostic.open_float, opts)
end

-- ====================== 3. 配置 Python (Pyright) ======================

vim.lsp.config("pyright", {
  cmd = { "pyright-langserver", "--stdio" },
  root_markers = { "pyproject.toml", "setup.py", "requirements.txt", ".git" },
  capabilities = capabilities,
  on_attach = on_attach,
  settings = {
    python = {
      analysis = {
        autoSearchPaths = true,
        diagnosticMode = "workspace",
        useLibraryCodeForTypes = true,
      },
    },
  },
})
vim.lsp.enable("pyright")

-- ====================== 4. 配置 Ansible (ansiblels) ======================

-- 1) 初始化配置
vim.lsp.config("ansiblels", {
  cmd = { "/usr/local/bin/ansible-language-server", "--stdio" },
  capabilities = capabilities,
  on_attach = on_attach,
  settings = {
    ansible = {
      python = { interpreterPath = "/usr/bin/python3" },
      ansible = { path = "/usr/bin/ansible" },
      validation = { enabled = true, lint = { enabled = true } },
    },
  },
})

-- 2) 【暴力平替】：移除所有复杂的路径和标志物判断
-- 只要你用 Neovim 打开以 .yml 或 .yaml 结尾的文件，就不讲道理地直接强行启动并挂载 ansiblels！
vim.api.nvim_create_autocmd({ "BufRead", "BufNewFile" }, {
  pattern = { "*.yml", "*.yaml" },
  callback = function(args)
    -- 强行将文件类型改为 yaml.ansible
    vim.bo[args.buf].filetype = "yaml.ansible"
    
    -- 强行把当前文件所在的目录作为它的根目录，彻底拒绝 Root directory: nil
    local current_dir = vim.fs.dirname(vim.api.nvim_buf_get_name(args.buf))
    
    -- 100% 对当前 buffer 暴力拉起并 Attach
    vim.lsp.start("ansiblels", { 
      bufnr = args.buf,
      root_dir = current_dir,
    })
  end,
})


-- ====================== 5. nvim-cmp 补全引擎与新版 LSP 桥梁 ======================

local cmp = require("cmp")
local luasnip = require("luasnip")

-- 1) 加载 VSCode 样式的代码片段
require("luasnip.loaders.from_vscode").lazy_load()
luasnip.config.setup({ history = true, updateevents = "TextChanged,TextChangedI" })

-- 核心关键：当类型是 yaml.ansible 时，让 luasnip 能够跨界读取 yaml 和 ansible 两个库的 Snippets
luasnip.filetype_extend("yaml.ansible", { "yaml", "ansible" })

-- 核心关键：将新版原生 LSP 托管的自动补全数据无缝同步给 nvim-cmp
vim.api.nvim_create_autocmd("LspAttach", {
  callback = function(args)
    local client = vim.lsp.get_client_by_id(args.data.client_id)
    if client and client.supports_method("textDocument/completion") then
      vim.bo[args.buf].omnifunc = "v:lua.vim.lsp.omnifunc"
    end
  end,
})

-- 2) nvim-cmp 引擎主配置
cmp.setup({
  snippet = {
    expand = function(args) luasnip.lsp_expand(args.body) end
  },
  mapping = cmp.mapping.preset.insert({
    ["<TAB>"] = cmp.mapping(function(fallback)
      if cmp.visible() then
        cmp.select_next_item()
      elseif luasnip.expand_or_jumpable() then
        luasnip.expand_or_jump()
      else
        fallback()
      end
    end, { "i", "s" }),
    ["<S-TAB>"] = cmp.mapping(function(fallback)
      if cmp.visible() then
        cmp.select_prev_item()
      elseif luasnip.jumpable(-1) then
        luasnip.jump(-1)
      else
        fallback()
      end
    end, { "i", "s" }),
    ["<CR>"] = cmp.mapping.confirm({ select = true, behavior = cmp.ConfirmBehavior.Replace }),
    ["<ESC>"] = cmp.mapping.abort(),
    ["<C-Space>"] = cmp.mapping.complete(), -- 强制唤醒快捷键
  }),
  
  sources = cmp.config.sources({
    { name = "nvim_lsp", priority = 1000 },
    -- 核心关键：加入 omnifunc（新旧版原生补全桥梁）作为高级后备源，杜绝因 API 变动导致的断联不弹窗
    { name = "omni", priority = 900 }, 
    { name = "luasnip", priority = 750 },
    { name = "path", priority = 500 },
    { name = "buffer", priority = 250 },
  }),
  
  window = {
    completion = cmp.config.window.bordered({ border = "rounded" }),
    documentation = cmp.config.window.bordered({ border = "rounded" }),
  },
  formatting = {
    fields = { "abbr", "kind", "menu" },
    format = function(entry, vim_item)
      vim_item.menu = ({
        nvim_lsp = "[LSP]",
        omni     = "[Ansible LSP]",
        luasnip  = "[Snippet]",
        path     = "[Path]",
        buffer   = "[Buffer]",
      })[entry.source.name]
      return vim_item
    end,
  },
})

-- ====================== 6. 括号自动补全与 Ansible 插值优化 ======================

local autopairs = require("nvim-autopairs")
autopairs.setup({
  check_ts = true,
  ts_config = {
    python = { "string", "comment" },
    lua = { "string", "comment" },
    yaml = { "string", "comment" }, -- 开启对 YAML 的树解析校验
  },
  disable_filetype = { "TelescopePrompt", "vim" },
  fast_wrap = {
    map = "<M-e>",
    chars = { "{", "[", "(", '"', "'", '"""', "'''" },
    pattern = [=[[%'%"%)%>%]%)%}%,]]=],
    end_key = "$",
    keys = "qwertyuiopzxcvbnmasdfghjkl",
    check_comma = true,
    highlight = "Search",
    highlight_grey = "Comment"
  }
})

-- 核心优化：针对 Ansible Jinja2 双大括号变量插值进行“空格智能联动扩展”
-- 当输入双大括号并按空格时，自动扩充为两边单空格对齐（如 {{ | }} -> {{  |  }}）
local Rule = require('nvim-autopairs.rule')
local cond = require('nvim-autopairs.conds')

autopairs.add_rules({
  Rule(' ', ' ')
    :with_pair(function(opts)
      local pair = opts.line:sub(opts.col - 1, opts.col)
      return vim.tbl_contains({ '()', '[]', '{}' }, pair)
    end)
    :with_move(cond.none())
    :with_cr(cond.none())
    :with_del(function(opts)
      local col = vim.api.nvim_win_get_cursor(0)
      local context = opts.line:sub(col - 1, col + 2)
      return vim.tbl_contains({ '(  )', '[  ]', '{  }' }, context)
    end),
  Rule('{{', '}}', { "yaml", "yaml.ansible" })
    :with_pair(cond.not_after_regex('%}'))
})

-- 括号与 cmp 自动补全确认键（CR）联动
local cmp_autopairs = require("nvim-autopairs.completion.cmp")
cmp.event:on("confirm_done", cmp_autopairs.on_confirm_done())

-- ====================== 7. venv-selector 虚拟环境配置 ======================

require("venv-selector").setup({
  auto_refresh = true,
  search_workspace = true,
  search_venv_managers = true,
  name = { "venv", ".venv", "env" },
  auto_select = true,
})

vim.api.nvim_create_autocmd({ "FileType", "BufEnter" }, {
  pattern = "python",
  callback = function()
    vim.cmd("silent! VenvSelectCached")
  end,
})

